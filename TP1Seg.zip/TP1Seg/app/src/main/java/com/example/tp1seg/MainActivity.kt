package com.example.tp1seg

import android.Manifest
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

        lateinit var fusedLocationProviderClient : FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }
    fun pegarLocalizacao(view:View){

        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED){
            fusedLocationProviderClient.lastLocation.addOnCompleteListener{
                var geocoder = Geocoder(this, Locale.getDefault())
                var localizacao : List<Address> = geocoder.getFromLocation(it.result!!.latitude,
                    it.result!!.longitude,
                    1)
                var endereco = localizacao.get(0).getAddressLine(0)
                Toast.makeText(this, endereco, Toast.LENGTH_LONG).show()
            }


        }else{
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1)
        }
    }
    fun getLocalization(view: View){
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            fusedLocationProviderClient.lastLocation.addOnCompleteListener{
                val geocoder = Geocoder(this, Locale.getDefault())
                val enderecos : List<Address> = geocoder.getFromLocation(it.result!!.latitude, it.result!!.longitude, 1)
                val endereco = enderecos.get(0).getAddressLine(0)
                txtVwCountry.text = endereco
                val sdf = SimpleDateFormat("dd-MM-yyyy-hh-mm-ss")
                val currentDate = sdf.format(getCurrentDateTime())
                Toast.makeText(this, currentDate, Toast.LENGTH_LONG).show()

            }
        }else{
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 100)
        }

    }
}
