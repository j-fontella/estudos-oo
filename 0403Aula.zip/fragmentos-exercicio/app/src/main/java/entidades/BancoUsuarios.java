package entidades;

import android.app.Activity;
import android.widget.Toast;

import com.example.a0403aula.LoginActivity;

import java.util.ArrayList;

public class BancoUsuarios {

    private ArrayList<Usuario> bancoDeUsuarios = new ArrayList<>();




    public void addUsuario(String nome, int senha){
        bancoDeUsuarios.add(new Usuario(nome, senha));
    }

    public ArrayList<Usuario> getBancoDeUsuarios() {
        return bancoDeUsuarios;
    }
}
