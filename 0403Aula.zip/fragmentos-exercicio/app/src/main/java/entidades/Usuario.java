package entidades;

public class Usuario {
    private String nome;
    private int senha;

    public Usuario(String nome, int senha) {
        this.nome = nome;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public int getSenha() {
        return senha;
    }

    public boolean autentica(int senha){
        if (this.senha == senha){
            return true;
        }
        return false;
    }


}
