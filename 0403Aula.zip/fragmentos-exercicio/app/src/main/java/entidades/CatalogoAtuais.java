package entidades;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;

public class CatalogoAtuais {

    private ArrayList<Livro> listaLivros = new ArrayList<>();

    private void addLivro(String nome, Drawable imagem){
        listaLivros.add(new Livro(nome, imagem));
    }

}
