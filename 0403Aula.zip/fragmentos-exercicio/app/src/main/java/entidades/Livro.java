package entidades;

import android.graphics.drawable.Drawable;

public class Livro {
    private String titulo;
    private Drawable imagem;


    public Livro(String titulo, Drawable imagem) {
        this.titulo = titulo;
        this.imagem = imagem;
    }
    public Livro(String titulo) {
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public Drawable getImagem() {
        return imagem;
    }


}
