package com.example.a0403aula.ViewModel

import androidx.lifecycle.ViewModel
import entidades.Livro

class LivroViewModel : ViewModel() {
    var livro : Livro? = null



}