package com.example.a0403aula

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import entidades.BancoUsuarios
import entidades.Usuario
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    var banco = BancoUsuarios()
    var finded:Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

    }

    fun direcionarMenu(view: View){
        val intent = Intent(this, MenuActivity::class.java)
        val nomeDigitado = editText.text.toString()
        val senhaDigitada = editText2.text.toString()
        var user = Usuario("Conta não encontrada", 0)

        if (nomeDigitado.isNullOrEmpty() || senhaDigitada.isNullOrEmpty()){
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_LONG).show()
        }
        else{
            if(banco.bancoDeUsuarios.isEmpty()){
                Toast.makeText(this, "Usuario nao encontrado no banco de dados", Toast.LENGTH_LONG).show()
            }
            else{
                banco.bancoDeUsuarios.forEach {
                    if(it.nome == nomeDigitado){
                       finded = true
                        user = it
                    }
                }
                if(finded == false){
                    Toast.makeText(this, "Conta nao encontrada", Toast.LENGTH_LONG).show()
                    return
                }
                if (user.senha == senhaDigitada.toInt()){
                    startActivity(intent)
                }
                else{
                    Toast.makeText(this, "Senha incorreta", Toast.LENGTH_LONG).show()
                }

            }
        }
        finded = false
    }
    fun cadastrar(view : View){
        val nome = editText3.text.toString()
        val senha = editText4.text.toString()

        if (nome.isNullOrEmpty() || senha.isNullOrEmpty()){
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_LONG).show()

        }
        else{
            if (banco.bancoDeUsuarios.isEmpty()){
                banco.addUsuario(nome, senha.toInt())
                Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_LONG).show()
            }
            else{
                banco.bancoDeUsuarios.forEach {
                    if (it.nome == nome)
                    {
                        finded = true
                    }
                }
                if(finded == false){
                    banco.addUsuario(nome, senha.toInt())
                    Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this, "Usuario ja existe no banco de dados", Toast.LENGTH_LONG).show()
                }

            }
            finded = false

        }





    }

}
