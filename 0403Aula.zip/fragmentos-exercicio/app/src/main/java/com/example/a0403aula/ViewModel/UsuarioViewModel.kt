package com.example.a0403aula.ViewModel

import androidx.lifecycle.ViewModel

class UsuarioViewModel : ViewModel() {

}