package com.example.a0403aula

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.a0403aula.ViewModel.LivroViewModel
import entidades.BancoUsuarios
import entidades.Livro
import kotlinx.android.synthetic.main.activity_menu.*

class MenuActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        bottom_menu2.setupWithNavController(
            findNavController(R.id.fragment)
        )

        var livroViewModel = ViewModelProviders.of(this) [LivroViewModel::class.java]
        livroViewModel.livro = Livro("SQL Expert!")

    }



}
